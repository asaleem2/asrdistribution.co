
# Asr Distribution Co. Website

Static site for Asr Distribution Co. Built with a brand SVG logo, product gallery, and PDF downloads.

## Local Preview
Open `index.html` in a browser.

## Deploy to GitHub Pages
1. Create a new repo (e.g., `asr-site`) in your GitHub account.
2. Upload all files from this folder **including** `/assets` and the `CNAME` file.
3. In **Settings → Pages**:  
   - **Build and deployment** → Source: **Deploy from a branch**  
   - Branch: **main** (root)
4. At your registrar, add DNS for `asrdistribution.co`:
   - **CNAME**: `asrdistribution.co` → `USERNAME.github.io` (replace USERNAME)
   - Optional A records: `185.199.108.153`, `185.199.109.153`, `185.199.110.153`, `185.199.111.153`
5. Visit `https://asrdistribution.co` when DNS propagates.

## Contact
hello@asrdistribution.co
